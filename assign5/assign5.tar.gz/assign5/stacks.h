#include <string>
using namespace std;
class Stacks
{
	public:
	string printername2;
	string filename2;
	string colour;
	Stacks(string pname, string fname, string c);
};