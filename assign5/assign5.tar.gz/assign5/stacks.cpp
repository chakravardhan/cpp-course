#include <string>
#include "stacks.h"
using namespace std;
Stacks::Stacks(string pname, string fname, string c)
{
	printername2=pname;
	filename2=fname;
	colour=c;
}